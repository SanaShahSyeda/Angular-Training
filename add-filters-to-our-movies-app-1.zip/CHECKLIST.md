- Use the `filterMovieList` from `movies.service` to get an Observable of filtered movies
- When the app loads, all movies are displayed
- |
    Typing "ph" in the title filter input displays only two movies: "Harry Potter and the Philosopher's Stone" and "Harry Potter and the Order of the Phoenix"
- |
    Typing "2007" in the year filter displays only one movie: "Harry Potter and the Order of the Phoenix"
