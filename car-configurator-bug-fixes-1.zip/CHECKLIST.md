- "When the app loads, select a Cybertruck in Satin Black color. Move on to step 2 and select Cyberbeast with Yoke Steering Wheel. Go to step 3. The app must display:
```
  Your Tesla Cybertruck
  Cyberbeast - Tri Motor All-Wheel Drive - $99,990.00
  Range: 320 miles - Max speed: 130
  Satin Black Color - $6,500.00
  Yoke Steering Wheel - $1,000.00
  TOTAL COST -  $106,490.00
```"
- "Click on step 1. \"Cybertruck\" is selected in the first dropdown and \"Satin Black\" is selected as the color.
- Select a \"Model 3\" with \"Deep Blue Metallic\" color. Move on to step 2. Step 3 must be disabled before you select a config."
- "Select the \"Long Range\" config. You can now click on step 3 and see the following summary with no more \"Yoke Steering Wheel\" option:
```
  Your Tesla Model 3
  Long Range - Dual Motor All-Wheel Drive - $45,990.00
  Range: 333 miles - Max speed: 145
  Deep Blue Metallic Color - $1,000.00
  TOTAL COST -  $46,990.00
```"
